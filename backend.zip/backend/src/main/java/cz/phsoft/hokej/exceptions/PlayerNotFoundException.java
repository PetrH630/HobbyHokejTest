package cz.phsoft.hokej.exceptions;

import org.springframework.http.HttpStatus;

/**
 * Výjimka signalizující, že požadovaný hráč nebyl nalezen.
 *
 * Může být vyhozena jak při hledání podle ID, tak při hledání
 * podle e-mailu.
 *
 * Typicky mapováno na HTTP 404 (Not Found).
 */
public class PlayerNotFoundException extends BusinessException {

    public PlayerNotFoundException(Long playerId) {
        super("BE - Hráč s ID " + playerId + " nenalezen.", HttpStatus.NOT_FOUND);
    }

    public PlayerNotFoundException(String email) {
        super("BE - Hráč s e-mailem " + email + " nenalezen.", HttpStatus.NOT_FOUND);
    }

    /**
     * Alternativní konstruktor s vlastní chybovou zprávou.
     */
    public PlayerNotFoundException(String message, String Email) {
        super(message, HttpStatus.NOT_FOUND);
    }
}
