package cz.phsoft.hokej.data.enums;

public enum LandingPage {
    DASHBOARD, // Přehled
    PLAYERS,  // Hráči
    MATCHES,    // Zápasy
}
