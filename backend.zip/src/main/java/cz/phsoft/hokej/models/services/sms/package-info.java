/**
 * SMS subsystém aplikace.
 *
 * Obsahuje třídy zodpovědné za skládání textů SMS zpráv
 * a jejich odesílání prostřednictvím SMS brány.
 *
 * Tento balíček je používán servisní vrstvou při odesílání
 * notifikací hráčům a uživatelům formou SMS.
 */
package cz.phsoft.hokej.models.services.sms;
